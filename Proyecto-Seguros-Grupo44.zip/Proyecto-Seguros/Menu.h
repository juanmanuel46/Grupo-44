#ifndef MENU_H
#define MENU_H

void menuPrincipal();
void menuClientes();
void menuPolizas();
void menuSiniestros();
void menuVehiculos();
void menuVencimientos();
void menuInformes();
void menuCompanias();

// Funciones auxiliares
void mostrarDinero(float cantidad);

#endif






